`2.0.0`
-------

- **Improvement:** use ``make_request`` wrapper instead of direct access to ``requests`` package.

`1.0.0`
-------

- **Init version**
